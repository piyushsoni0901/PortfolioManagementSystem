package com.cognizant.portfoliomanagement.WebPortal.Model;

public class AuthResponse {
	private String uid;
	private String name;
	private boolean isValid;
}
